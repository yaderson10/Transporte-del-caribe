import 'package:flutter/material.dart';
import '../presentation/schedule_viewer_screen/schedule_viewer_screen.dart';
import '../presentation/passenger_dashboard/passenger_dashboard.dart';
import '../presentation/login_screen/login_screen.dart';
import '../presentation/role_selection_screen/role_selection_screen.dart';
import '../presentation/registration_screen/registration_screen.dart';
import '../presentation/route_information_screen/route_information_screen.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String scheduleViewer = '/schedule-viewer-screen';
  static const String passengerDashboard = '/passenger-dashboard';
  static const String login = '/login-screen';
  static const String roleSelection = '/role-selection-screen';
  static const String registration = '/registration-screen';
  static const String routeInformation = '/route-information-screen';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const LoginScreen(),
    scheduleViewer: (context) => const ScheduleViewerScreen(),
    passengerDashboard: (context) => PassengerDashboard(),
    login: (context) => const LoginScreen(),
    roleSelection: (context) => const RoleSelectionScreen(),
    registration: (context) => const RegistrationScreen(),
    routeInformation: (context) => const RouteInformationScreen(),
    // TODO: Add your other routes here
  };
}