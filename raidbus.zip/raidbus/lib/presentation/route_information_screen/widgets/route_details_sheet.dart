import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class RouteDetailsSheet extends StatefulWidget {
  final Function(String) onCompanySelected;
  final Function() onViewSchedules;

  const RouteDetailsSheet({
    Key? key,
    required this.onCompanySelected,
    required this.onViewSchedules,
  }) : super(key: key);

  @override
  State<RouteDetailsSheet> createState() => _RouteDetailsSheetState();
}

class _RouteDetailsSheetState extends State<RouteDetailsSheet>
    with TickerProviderStateMixin {
  late TabController _tabController;
  final PageController _pageController = PageController();
  int _selectedCompanyIndex = 0;

  final List<Map<String, dynamic>> _transportCompanies = [
    {
      "id": "1",
      "name": "Transporte Jairo Monzón",
      "rating": 4.5,
      "phone": "+505 2270-1234",
      "busType": "Autobús Ejecutivo",
      "amenities": [
        "Aire Acondicionado",
        "Asientos Reclinables",
        "WiFi",
        "Baño"
      ],
      "image":
          "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?fm=jpg&q=60&w=3000",
      "features": [
        "GPS Tracking",
        "Seguro de Pasajeros",
        "Conductor Profesional"
      ],
      "capacity": "45 pasajeros",
      "departureFrequency": "5 salidas diarias"
    },
    {
      "id": "2",
      "name": "Leonel Monzón",
      "rating": 4.3,
      "phone": "+505 2270-5678",
      "busType": "Autobús Estándar",
      "amenities": ["Aire Acondicionado", "Asientos Cómodos", "Música"],
      "image":
          "https://images.unsplash.com/photo-1570125909232-eb263c188f7e?fm=jpg&q=60&w=3000",
      "features": ["Horarios Puntuales", "Seguro Incluido"],
      "capacity": "50 pasajeros",
      "departureFrequency": "4 salidas diarias"
    },
    {
      "id": "3",
      "name": "Susana Monzón",
      "rating": 4.2,
      "phone": "+505 2270-9012",
      "busType": "Autobús Familiar",
      "amenities": ["Aire Acondicionado", "Espacio para Equipaje", "Snacks"],
      "image":
          "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?fm=jpg&q=60&w=3000",
      "features": ["Atención Familiar", "Precios Accesibles"],
      "capacity": "48 pasajeros",
      "departureFrequency": "3 salidas diarias"
    },
    {
      "id": "4",
      "name": "Juan Quintana",
      "rating": 4.4,
      "phone": "+505 2270-3456",
      "busType": "Autobús Premium",
      "amenities": [
        "Aire Acondicionado",
        "Asientos de Cuero",
        "WiFi",
        "TV",
        "Baño"
      ],
      "image":
          "https://images.unsplash.com/photo-1570125909232-eb263c188f7e?fm=jpg&q=60&w=3000",
      "features": ["Servicio Premium", "Entretenimiento", "Refrigerios"],
      "capacity": "40 pasajeros",
      "departureFrequency": "3 salidas diarias"
    },
    {
      "id": "5",
      "name": "Aragón",
      "rating": 4.1,
      "phone": "+505 2270-7890",
      "busType": "Autobús Estándar",
      "amenities": ["Aire Acondicionado", "Asientos Reclinables"],
      "image":
          "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?fm=jpg&q=60&w=3000",
      "features": ["Experiencia de 20 años", "Rutas Seguras"],
      "capacity": "52 pasajeros",
      "departureFrequency": "4 salidas diarias"
    },
    {
      "id": "6",
      "name": "Montoya",
      "rating": 4.0,
      "phone": "+505 2270-2468",
      "busType": "Autobús Económico",
      "amenities": ["Ventilación", "Asientos Básicos", "Radio"],
      "image":
          "https://images.unsplash.com/photo-1570125909232-eb263c188f7e?fm=jpg&q=60&w=3000",
      "features": ["Precios Económicos", "Servicio Confiable"],
      "capacity": "55 pasajeros",
      "departureFrequency": "6 salidas diarias"
    },
    {
      "id": "7",
      "name": "Amador",
      "rating": 4.3,
      "phone": "+505 2270-1357",
      "busType": "Autobús Ejecutivo",
      "amenities": [
        "Aire Acondicionado",
        "WiFi",
        "Asientos Reclinables",
        "Baño"
      ],
      "image":
          "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?fm=jpg&q=60&w=3000",
      "features": ["Tecnología Moderna", "Comodidad Superior"],
      "capacity": "42 pasajeros",
      "departureFrequency": "4 salidas diarias"
    },
    {
      "id": "8",
      "name": "Centeno",
      "rating": 3.9,
      "phone": "+505 2270-9753",
      "busType": "Autobús Estándar",
      "amenities": ["Aire Acondicionado", "Asientos Cómodos"],
      "image":
          "https://images.unsplash.com/photo-1570125909232-eb263c188f7e?fm=jpg&q=60&w=3000",
      "features": ["Servicio Regular", "Horarios Flexibles"],
      "capacity": "50 pasajeros",
      "departureFrequency": "5 salidas diarias"
    },
    {
      "id": "9",
      "name": "Ingram",
      "rating": 4.2,
      "phone": "+505 2270-8642",
      "busType": "Autobús Familiar",
      "amenities": ["Aire Acondicionado", "Espacio Amplio", "Música"],
      "image":
          "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?fm=jpg&q=60&w=3000",
      "features": ["Ambiente Familiar", "Seguridad Garantizada"],
      "capacity": "47 pasajeros",
      "departureFrequency": "3 salidas diarias"
    },
    {
      "id": "10",
      "name": "Chow",
      "rating": 4.1,
      "phone": "+505 2270-5319",
      "busType": "Autobús Estándar",
      "amenities": ["Aire Acondicionado", "Asientos Reclinables", "Radio"],
      "image":
          "https://images.unsplash.com/photo-1570125909232-eb263c188f7e?fm=jpg&q=60&w=3000",
      "features": ["Puntualidad", "Buen Servicio"],
      "capacity": "49 pasajeros",
      "departureFrequency": "4 salidas diarias"
    },
    {
      "id": "11",
      "name": "Acevedo",
      "rating": 4.0,
      "phone": "+505 2270-7531",
      "busType": "Autobús Económico",
      "amenities": ["Ventilación Natural", "Asientos Básicos"],
      "image":
          "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?fm=jpg&q=60&w=3000",
      "features": ["Tarifas Bajas", "Servicio Básico"],
      "capacity": "54 pasajeros",
      "departureFrequency": "5 salidas diarias"
    },
    {
      "id": "12",
      "name": "Dunkan",
      "rating": 4.4,
      "phone": "+505 2270-9642",
      "busType": "Autobús Premium",
      "amenities": ["Aire Acondicionado", "WiFi", "TV", "Baño", "Refrigerios"],
      "image":
          "https://images.unsplash.com/photo-1570125909232-eb263c188f7e?fm=jpg&q=60&w=3000",
      "features": ["Lujo y Comodidad", "Entretenimiento Premium"],
      "capacity": "38 pasajeros",
      "departureFrequency": "2 salidas diarias"
    },
    {
      "id": "13",
      "name": "Fermín Romero",
      "rating": 4.2,
      "phone": "+505 2270-1598",
      "busType": "Autobús Ejecutivo",
      "amenities": ["Aire Acondicionado", "Asientos de Cuero", "WiFi"],
      "image":
          "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?fm=jpg&q=60&w=3000",
      "features": ["Servicio Ejecutivo", "Comodidad Premium"],
      "capacity": "44 pasajeros",
      "departureFrequency": "3 salidas diarias"
    },
    {
      "id": "14",
      "name": "Lazo",
      "rating": 3.8,
      "phone": "+505 2270-7410",
      "busType": "Autobús Estándar",
      "amenities": ["Aire Acondicionado", "Asientos Básicos", "Radio"],
      "image":
          "https://images.unsplash.com/photo-1570125909232-eb263c188f7e?fm=jpg&q=60&w=3000",
      "features": ["Servicio Confiable", "Precios Justos"],
      "capacity": "51 pasajeros",
      "departureFrequency": "4 salidas diarias"
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.4,
      minChildSize: 0.2,
      maxChildSize: 0.9,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: AppTheme.lightTheme.colorScheme.surface,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.1),
                blurRadius: 10,
                offset: const Offset(0, -2),
              ),
            ],
          ),
          child: Column(
            children: [
              // Drag handle
              Container(
                margin: EdgeInsets.only(top: 1.h),
                width: 12.w,
                height: 0.5.h,
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.outline,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),

              // Tab bar
              Container(
                margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: AppTheme.lightTheme.colorScheme.outline
                        .withValues(alpha: 0.3),
                  ),
                ),
                child: TabBar(
                  controller: _tabController,
                  indicator: BoxDecoration(
                    color: AppTheme.lightTheme.primaryColor,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  labelColor: Colors.white,
                  unselectedLabelColor:
                      AppTheme.lightTheme.colorScheme.onSurface,
                  dividerColor: Colors.transparent,
                  tabs: const [
                    Tab(text: 'Información de Ruta'),
                    Tab(text: 'Empresas de Transporte'),
                  ],
                ),
              ),

              // Tab content
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    _buildRouteInfoTab(scrollController),
                    _buildCompaniesTab(scrollController),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildRouteInfoTab(ScrollController scrollController) {
    return SingleChildScrollView(
      controller: scrollController,
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Route overview card
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(4.w),
            margin: EdgeInsets.only(bottom: 2.h),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.3),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'route',
                      color: AppTheme.lightTheme.primaryColor,
                      size: 24,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Managua ↔ Puerto Cabezas',
                      style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 2.h),
                Row(
                  children: [
                    Expanded(
                      child: _buildInfoItem(
                        icon: 'straighten',
                        label: 'Distancia',
                        value: '~380 km',
                      ),
                    ),
                    Expanded(
                      child: _buildInfoItem(
                        icon: 'schedule',
                        label: 'Duración',
                        value: '6-8 horas',
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 1.h),
                Row(
                  children: [
                    Expanded(
                      child: _buildInfoItem(
                        icon: 'directions_bus',
                        label: 'Empresas',
                        value: '14 operadores',
                      ),
                    ),
                    Expanded(
                      child: _buildInfoItem(
                        icon: 'departure_board',
                        label: 'Salidas',
                        value: 'Diarias',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Amenities section
          Text(
            'Servicios Disponibles',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 1.h),
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.3),
              ),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                        child:
                            _buildAmenityItem('ac_unit', 'Aire Acondicionado')),
                    Expanded(
                        child: _buildAmenityItem('wifi', 'WiFi Disponible')),
                  ],
                ),
                SizedBox(height: 2.h),
                Row(
                  children: [
                    Expanded(child: _buildAmenityItem('wc', 'Baños a Bordo')),
                    Expanded(child: _buildAmenityItem('tv', 'Entretenimiento')),
                  ],
                ),
                SizedBox(height: 2.h),
                Row(
                  children: [
                    Expanded(
                        child: _buildAmenityItem(
                            'local_cafe', 'Paradas de Descanso')),
                    Expanded(
                        child:
                            _buildAmenityItem('security', 'Seguro Incluido')),
                  ],
                ),
              ],
            ),
          ),
          SizedBox(height: 2.h),

          // Safety information
          Text(
            'Información de Seguridad',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 1.h),
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.3),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildSafetyItem('• Conductores profesionales certificados'),
                _buildSafetyItem('• Vehículos inspeccionados regularmente'),
                _buildSafetyItem('• Seguro de pasajeros incluido'),
                _buildSafetyItem('• Monitoreo GPS en tiempo real'),
                _buildSafetyItem('• Cumplimiento de normas de tránsito'),
              ],
            ),
          ),
          SizedBox(height: 4.h),
        ],
      ),
    );
  }

  Widget _buildCompaniesTab(ScrollController scrollController) {
    return Column(
      children: [
        // Company selector
        Container(
          height: 8.h,
          margin: EdgeInsets.symmetric(horizontal: 4.w),
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: _transportCompanies.length,
            itemBuilder: (context, index) {
              final isSelected = index == _selectedCompanyIndex;
              return GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedCompanyIndex = index;
                  });
                  _pageController.animateToPage(
                    index,
                    duration: const Duration(milliseconds: 300),
                    curve: Curves.easeInOut,
                  );
                  widget.onCompanySelected(_transportCompanies[index]['name']);
                },
                child: Container(
                  margin: EdgeInsets.only(right: 2.w),
                  padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? AppTheme.lightTheme.primaryColor
                        : AppTheme.lightTheme.colorScheme.surface,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isSelected
                          ? AppTheme.lightTheme.primaryColor
                          : AppTheme.lightTheme.colorScheme.outline
                              .withValues(alpha: 0.3),
                    ),
                  ),
                  child: Center(
                    child: Text(
                      _transportCompanies[index]['name'],
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: isSelected
                            ? Colors.white
                            : AppTheme.lightTheme.colorScheme.onSurface,
                        fontWeight:
                            isSelected ? FontWeight.bold : FontWeight.normal,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              );
            },
          ),
        ),

        SizedBox(height: 2.h),

        // Company details
        Expanded(
          child: PageView.builder(
            controller: _pageController,
            onPageChanged: (index) {
              setState(() {
                _selectedCompanyIndex = index;
              });
              widget.onCompanySelected(_transportCompanies[index]['name']);
            },
            itemCount: _transportCompanies.length,
            itemBuilder: (context, index) {
              return _buildCompanyCard(
                  _transportCompanies[index], scrollController);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildCompanyCard(
      Map<String, dynamic> company, ScrollController scrollController) {
    return SingleChildScrollView(
      controller: scrollController,
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Company header
          Container(
            width: double.infinity,
            height: 25.h,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              image: DecorationImage(
                image: NetworkImage(company['image']),
                fit: BoxFit.cover,
              ),
            ),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black.withValues(alpha: 0.7),
                  ],
                ),
              ),
              padding: EdgeInsets.all(4.w),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    company['name'],
                    style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 1.h),
                  Row(
                    children: [
                      ...List.generate(5, (index) {
                        return CustomIconWidget(
                          iconName: index < company['rating'].floor()
                              ? 'star'
                              : 'star_border',
                          color: Colors.amber,
                          size: 16,
                        );
                      }),
                      SizedBox(width: 2.w),
                      Text(
                        '${company['rating']}',
                        style:
                            AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          SizedBox(height: 2.h),

          // Company details
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.3),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: _buildDetailItem(
                        icon: 'directions_bus',
                        label: 'Tipo de Autobús',
                        value: company['busType'],
                      ),
                    ),
                    Expanded(
                      child: _buildDetailItem(
                        icon: 'people',
                        label: 'Capacidad',
                        value: company['capacity'],
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 2.h),
                Row(
                  children: [
                    Expanded(
                      child: _buildDetailItem(
                        icon: 'phone',
                        label: 'Teléfono',
                        value: company['phone'],
                      ),
                    ),
                    Expanded(
                      child: _buildDetailItem(
                        icon: 'schedule',
                        label: 'Frecuencia',
                        value: company['departureFrequency'],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          SizedBox(height: 2.h),

          // Amenities
          Text(
            'Comodidades',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 1.h),
          Wrap(
            spacing: 2.w,
            runSpacing: 1.h,
            children: (company['amenities'] as List).map((amenity) {
              return Container(
                padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.5.h),
                decoration: BoxDecoration(
                  color:
                      AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color:
                        AppTheme.lightTheme.primaryColor.withValues(alpha: 0.3),
                  ),
                ),
                child: Text(
                  amenity,
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.lightTheme.primaryColor,
                  ),
                ),
              );
            }).toList(),
          ),

          SizedBox(height: 2.h),

          // Features
          Text(
            'Características Especiales',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 1.h),
          Column(
            children: (company['features'] as List).map((feature) {
              return Container(
                margin: EdgeInsets.only(bottom: 1.h),
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'check_circle',
                      color: AppTheme.lightTheme.primaryColor,
                      size: 16,
                    ),
                    SizedBox(width: 2.w),
                    Expanded(
                      child: Text(
                        feature,
                        style: AppTheme.lightTheme.textTheme.bodyMedium,
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ),

          SizedBox(height: 2.h),

          // View schedules button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: widget.onViewSchedules,
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 2.h),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomIconWidget(
                    iconName: 'schedule',
                    color: Colors.white,
                    size: 20,
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    'Ver Horarios de ${company['name']}',
                    style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),

          SizedBox(height: 4.h),
        ],
      ),
    );
  }

  Widget _buildInfoItem({
    required String icon,
    required String label,
    required String value,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            CustomIconWidget(
              iconName: icon,
              color: AppTheme.lightTheme.primaryColor,
              size: 16,
            ),
            SizedBox(width: 1.w),
            Text(
              label,
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.7),
              ),
            ),
          ],
        ),
        SizedBox(height: 0.5.h),
        Text(
          value,
          style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildAmenityItem(String icon, String label) {
    return Row(
      children: [
        CustomIconWidget(
          iconName: icon,
          color: AppTheme.lightTheme.primaryColor,
          size: 20,
        ),
        SizedBox(width: 2.w),
        Expanded(
          child: Text(
            label,
            style: AppTheme.lightTheme.textTheme.bodySmall,
          ),
        ),
      ],
    );
  }

  Widget _buildSafetyItem(String text) {
    return Padding(
      padding: EdgeInsets.only(bottom: 0.5.h),
      child: Text(
        text,
        style: AppTheme.lightTheme.textTheme.bodyMedium,
      ),
    );
  }

  Widget _buildDetailItem({
    required String icon,
    required String label,
    required String value,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            CustomIconWidget(
              iconName: icon,
              color: AppTheme.lightTheme.primaryColor,
              size: 16,
            ),
            SizedBox(width: 1.w),
            Text(
              label,
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.7),
              ),
            ),
          ],
        ),
        SizedBox(height: 0.5.h),
        Text(
          value,
          style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}
