import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class WeatherWidget extends StatefulWidget {
  const WeatherWidget({Key? key}) : super(key: key);

  @override
  State<WeatherWidget> createState() => _WeatherWidgetState();
}

class _WeatherWidgetState extends State<WeatherWidget> {
  final List<Map<String, dynamic>> _weatherData = [
    {
      "city": "Managua",
      "temperature": 32,
      "condition": "Soleado",
      "icon": "wb_sunny",
      "humidity": 65,
      "windSpeed": 12,
      "description": "Día despejado, ideal para viajar"
    },
    {
      "city": "Matagalpa",
      "temperature": 24,
      "condition": "Parcialmente Nublado",
      "icon": "partly_cloudy_day",
      "humidity": 78,
      "windSpeed": 8,
      "description": "Clima fresco en la montaña"
    },
    {
      "city": "Jinotega",
      "temperature": 22,
      "condition": "Nublado",
      "icon": "cloud",
      "humidity": 82,
      "windSpeed": 6,
      "description": "Posibles lloviznas ligeras"
    },
    {
      "city": "Siuna",
      "temperature": 28,
      "condition": "Lluvia Ligera",
      "icon": "grain",
      "humidity": 88,
      "windSpeed": 10,
      "description": "Lluvia intermitente"
    },
    {
      "city": "Puerto Cabezas",
      "temperature": 30,
      "condition": "Parcialmente Nublado",
      "icon": "partly_cloudy_day",
      "humidity": 75,
      "windSpeed": 15,
      "description": "Brisa marina agradable"
    },
  ];

  bool _isExpanded = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          // Header
          GestureDetector(
            onTap: () {
              setState(() {
                _isExpanded = !_isExpanded;
              });
            },
            child: Container(
              padding: EdgeInsets.all(4.w),
              child: Row(
                children: [
                  CustomIconWidget(
                    iconName: 'wb_cloudy',
                    color: AppTheme.lightTheme.primaryColor,
                    size: 24,
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Condiciones Climáticas',
                          style: AppTheme.lightTheme.textTheme.titleMedium
                              ?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          'A lo largo de la ruta',
                          style:
                              AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                            color: AppTheme.lightTheme.colorScheme.onSurface
                                .withValues(alpha: 0.7),
                          ),
                        ),
                      ],
                    ),
                  ),
                  CustomIconWidget(
                    iconName: _isExpanded ? 'expand_less' : 'expand_more',
                    color: AppTheme.lightTheme.colorScheme.onSurface,
                    size: 24,
                  ),
                ],
              ),
            ),
          ),

          // Weather summary (always visible)
          if (!_isExpanded) _buildWeatherSummary(),

          // Detailed weather (expandable)
          if (_isExpanded) _buildDetailedWeather(),
        ],
      ),
    );
  }

  Widget _buildWeatherSummary() {
    return Container(
      padding: EdgeInsets.fromLTRB(4.w, 0, 4.w, 4.w),
      child: Row(
        children: [
          Expanded(
            child: _buildWeatherSummaryItem(
              _weatherData[0], // Managua
              'Origen',
            ),
          ),
          Container(
            width: 1,
            height: 6.h,
            color:
                AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.3),
            margin: EdgeInsets.symmetric(horizontal: 4.w),
          ),
          Expanded(
            child: _buildWeatherSummaryItem(
              _weatherData[4], // Puerto Cabezas
              'Destino',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWeatherSummaryItem(Map<String, dynamic> weather, String label) {
    return Column(
      children: [
        Text(
          label,
          style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
            color: AppTheme.lightTheme.colorScheme.onSurface
                .withValues(alpha: 0.7),
          ),
        ),
        SizedBox(height: 0.5.h),
        Text(
          weather['city'],
          style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 1.h),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomIconWidget(
              iconName: weather['icon'],
              color: _getWeatherColor(weather['condition']),
              size: 24,
            ),
            SizedBox(width: 2.w),
            Text(
              '${weather['temperature']}°C',
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        SizedBox(height: 0.5.h),
        Text(
          weather['condition'],
          style: AppTheme.lightTheme.textTheme.bodySmall,
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildDetailedWeather() {
    return Container(
      padding: EdgeInsets.fromLTRB(4.w, 0, 4.w, 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Condiciones por Ciudad',
            style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 2.h),

          // Weather cards
          Column(
            children: _weatherData.map((weather) {
              return Container(
                margin: EdgeInsets.only(bottom: 2.h),
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: AppTheme.lightTheme.colorScheme.outline
                        .withValues(alpha: 0.3),
                  ),
                ),
                child: Row(
                  children: [
                    // Weather icon and temperature
                    Container(
                      width: 20.w,
                      child: Column(
                        children: [
                          CustomIconWidget(
                            iconName: weather['icon'],
                            color: _getWeatherColor(weather['condition']),
                            size: 32,
                          ),
                          SizedBox(height: 1.h),
                          Text(
                            '${weather['temperature']}°C',
                            style: AppTheme.lightTheme.textTheme.titleMedium
                                ?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),

                    SizedBox(width: 4.w),

                    // Weather details
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            weather['city'],
                            style: AppTheme.lightTheme.textTheme.titleSmall
                                ?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 0.5.h),
                          Text(
                            weather['condition'],
                            style: AppTheme.lightTheme.textTheme.bodyMedium,
                          ),
                          SizedBox(height: 0.5.h),
                          Text(
                            weather['description'],
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: AppTheme.lightTheme.colorScheme.onSurface
                                  .withValues(alpha: 0.7),
                            ),
                          ),
                          SizedBox(height: 1.h),

                          // Additional weather info
                          Row(
                            children: [
                              Expanded(
                                child: Row(
                                  children: [
                                    CustomIconWidget(
                                      iconName: 'water_drop',
                                      color: Colors.blue,
                                      size: 14,
                                    ),
                                    SizedBox(width: 1.w),
                                    Text(
                                      '${weather['humidity']}%',
                                      style: AppTheme
                                          .lightTheme.textTheme.bodySmall,
                                    ),
                                  ],
                                ),
                              ),
                              Expanded(
                                child: Row(
                                  children: [
                                    CustomIconWidget(
                                      iconName: 'air',
                                      color: Colors.grey,
                                      size: 14,
                                    ),
                                    SizedBox(width: 1.w),
                                    Text(
                                      '${weather['windSpeed']} km/h',
                                      style: AppTheme
                                          .lightTheme.textTheme.bodySmall,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ),

          // Weather advice
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.3),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'info',
                      color: AppTheme.lightTheme.primaryColor,
                      size: 20,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Recomendaciones de Viaje',
                      style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: AppTheme.lightTheme.primaryColor,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 1.h),
                Text(
                  '• Lleve ropa ligera para Managua y Puerto Cabezas\n'
                  '• Traiga una chaqueta para las zonas montañosas\n'
                  '• Considere un paraguas para Siuna y Jinotega\n'
                  '• Manténgase hidratado durante el viaje',
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.lightTheme.primaryColor,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _getWeatherColor(String condition) {
    switch (condition.toLowerCase()) {
      case 'soleado':
        return Colors.orange;
      case 'parcialmente nublado':
        return Colors.blue;
      case 'nublado':
        return Colors.grey;
      case 'lluvia ligera':
        return Colors.blueAccent;
      default:
        return AppTheme.lightTheme.primaryColor;
    }
  }
}
