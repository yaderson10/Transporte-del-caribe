import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class RouteMapWidget extends StatefulWidget {
  final Function(String) onCompanySelected;

  const RouteMapWidget({
    Key? key,
    required this.onCompanySelected,
  }) : super(key: key);

  @override
  State<RouteMapWidget> createState() => _RouteMapWidgetState();
}

class _RouteMapWidgetState extends State<RouteMapWidget> {
  GoogleMapController? _mapController;
  final Set<Marker> _markers = {};
  final Set<Polyline> _polylines = {};

  // Route coordinates (Managua to Puerto Cabezas)
  static const LatLng _managua = LatLng(12.1364, -86.2514);
  static const LatLng _puertoCabezas = LatLng(14.0353, -83.3881);

  // Intermediate stops
  final List<Map<String, dynamic>> _routeStops = [
    {
      "name": "Managua Terminal",
      "position": LatLng(12.1364, -86.2514),
      "type": "terminal",
      "description": "Terminal principal de autobuses"
    },
    {
      "name": "Matagalpa",
      "position": LatLng(12.9255, -85.9172),
      "type": "stop",
      "description": "Parada intermedia - 2 horas desde Managua"
    },
    {
      "name": "Jinotega",
      "position": LatLng(13.0919, -86.0027),
      "type": "stop",
      "description": "Parada de descanso - 3 horas desde Managua"
    },
    {
      "name": "Siuna",
      "position": LatLng(13.7333, -84.7667),
      "type": "stop",
      "description": "Parada intermedia - 5 horas desde Managua"
    },
    {
      "name": "Puerto Cabezas Terminal",
      "position": LatLng(14.0353, -83.3881),
      "type": "terminal",
      "description": "Terminal de destino"
    },
  ];

  @override
  void initState() {
    super.initState();
    _initializeMapData();
  }

  void _initializeMapData() {
    _createMarkers();
    _createPolylines();
  }

  void _createMarkers() {
    for (int i = 0; i < _routeStops.length; i++) {
      final stop = _routeStops[i];
      _markers.add(
        Marker(
          markerId: MarkerId('stop_$i'),
          position: stop['position'] as LatLng,
          infoWindow: InfoWindow(
            title: stop['name'] as String,
            snippet: stop['description'] as String,
          ),
          icon: stop['type'] == 'terminal'
              ? BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue)
              : BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueOrange),
          onTap: () => _onMarkerTapped(stop),
        ),
      );
    }
  }

  void _createPolylines() {
    final List<LatLng> routePoints =
        _routeStops.map((stop) => stop['position'] as LatLng).toList();

    _polylines.add(
      Polyline(
        polylineId: const PolylineId('main_route'),
        points: routePoints,
        color: AppTheme.lightTheme.primaryColor,
        width: 4,
        patterns: [],
      ),
    );
  }

  void _onMarkerTapped(Map<String, dynamic> stop) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 12.w,
                height: 0.5.h,
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.outline,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              stop['name'] as String,
              style: AppTheme.lightTheme.textTheme.titleLarge,
            ),
            SizedBox(height: 1.h),
            Text(
              stop['description'] as String,
              style: AppTheme.lightTheme.textTheme.bodyMedium,
            ),
            SizedBox(height: 2.h),
            if (stop['type'] == 'stop') ...[
              Row(
                children: [
                  CustomIconWidget(
                    iconName: 'local_cafe',
                    color: AppTheme.lightTheme.primaryColor,
                    size: 20,
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    'Servicios disponibles',
                    style: AppTheme.lightTheme.textTheme.bodyMedium,
                  ),
                ],
              ),
              SizedBox(height: 1.h),
              Text(
                '• Cafetería\n• Baños\n• Tienda de conveniencia',
                style: AppTheme.lightTheme.textTheme.bodySmall,
              ),
            ],
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  void _onMapCreated(GoogleMapController controller) {
    _mapController = controller;

    // Fit bounds to show entire route
    if (_markers.isNotEmpty) {
      final bounds = _calculateBounds();
      _mapController!.animateCamera(
        CameraUpdate.newLatLngBounds(bounds, 100.0),
      );
    }
  }

  LatLngBounds _calculateBounds() {
    double minLat = _routeStops.first['position'].latitude;
    double maxLat = _routeStops.first['position'].latitude;
    double minLng = _routeStops.first['position'].longitude;
    double maxLng = _routeStops.first['position'].longitude;

    for (final stop in _routeStops) {
      final pos = stop['position'] as LatLng;
      minLat = minLat < pos.latitude ? minLat : pos.latitude;
      maxLat = maxLat > pos.latitude ? maxLat : pos.latitude;
      minLng = minLng < pos.longitude ? minLng : pos.longitude;
      maxLng = maxLng > pos.longitude ? maxLng : pos.longitude;
    }

    return LatLngBounds(
      southwest: LatLng(minLat, minLng),
      northeast: LatLng(maxLat, maxLng),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 100.h,
      child: Stack(
        children: [
          GoogleMap(
            onMapCreated: _onMapCreated,
            initialCameraPosition: const CameraPosition(
              target: LatLng(13.0, -85.0), // Center between cities
              zoom: 7.0,
            ),
            markers: _markers,
            polylines: _polylines,
            mapType: MapType.normal,
            myLocationEnabled: false,
            myLocationButtonEnabled: false,
            zoomControlsEnabled: false,
            mapToolbarEnabled: false,
            compassEnabled: true,
            trafficEnabled: true,
          ),

          // Map controls overlay
          Positioned(
            top: 8.h,
            right: 4.w,
            child: Column(
              children: [
                _buildMapControlButton(
                  icon: 'my_location',
                  onTap: () => _centerOnRoute(),
                ),
                SizedBox(height: 2.h),
                _buildMapControlButton(
                  icon: 'layers',
                  onTap: () => _showMapTypeSelector(),
                ),
              ],
            ),
          ),

          // Route info overlay
          Positioned(
            top: 8.h,
            left: 4.w,
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surface
                    .withValues(alpha: 0.9),
                borderRadius: BorderRadius.circular(8),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.1),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Managua ↔ Puerto Cabezas',
                    style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 0.5.h),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CustomIconWidget(
                        iconName: 'schedule',
                        color: AppTheme.lightTheme.primaryColor,
                        size: 16,
                      ),
                      SizedBox(width: 1.w),
                      Text(
                        '6-8 horas',
                        style: AppTheme.lightTheme.textTheme.bodySmall,
                      ),
                    ],
                  ),
                  SizedBox(height: 0.5.h),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CustomIconWidget(
                        iconName: 'straighten',
                        color: AppTheme.lightTheme.primaryColor,
                        size: 16,
                      ),
                      SizedBox(width: 1.w),
                      Text(
                        '~380 km',
                        style: AppTheme.lightTheme.textTheme.bodySmall,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMapControlButton({
    required String icon,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 12.w,
        height: 12.w,
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: BorderRadius.circular(8),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.1),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Center(
          child: CustomIconWidget(
            iconName: icon,
            color: AppTheme.lightTheme.primaryColor,
            size: 24,
          ),
        ),
      ),
    );
  }

  void _centerOnRoute() {
    if (_mapController != null) {
      final bounds = _calculateBounds();
      _mapController!.animateCamera(
        CameraUpdate.newLatLngBounds(bounds, 100.0),
      );
    }
  }

  void _showMapTypeSelector() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Tipo de Mapa',
              style: AppTheme.lightTheme.textTheme.titleMedium,
            ),
            SizedBox(height: 2.h),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'map',
                color: AppTheme.lightTheme.primaryColor,
                size: 24,
              ),
              title: const Text('Normal'),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'satellite',
                color: AppTheme.lightTheme.primaryColor,
                size: 24,
              ),
              title: const Text('Satélite'),
              onTap: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _mapController?.dispose();
    super.dispose();
  }
}
