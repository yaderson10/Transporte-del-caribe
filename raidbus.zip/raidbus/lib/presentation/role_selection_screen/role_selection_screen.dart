import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/change_later_widget.dart';
import './widgets/logo_header_widget.dart';
import './widgets/role_card_widget.dart';

class RoleSelectionScreen extends StatefulWidget {
  const RoleSelectionScreen({Key? key}) : super(key: key);

  @override
  State<RoleSelectionScreen> createState() => _RoleSelectionScreenState();
}

class _RoleSelectionScreenState extends State<RoleSelectionScreen>
    with SingleTickerProviderStateMixin {
  String? _selectedRole;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  final List<Map<String, dynamic>> _roles = [
    {
      'id': 'passenger',
      'title': 'Pasajero',
      'description':
          'Consulta horarios, planifica viajes y recibe notificaciones de rutas',
      'iconName': 'luggage',
      'route': '/login-screen',
    },
    {
      'id': 'driver',
      'title': 'Conductor',
      'description':
          'Gestiona rutas asignadas, marca inicio/fin de viajes y actualiza horarios',
      'iconName': 'drive_eta',
      'route': '/login-screen',
    },
  ];

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _loadSavedRole();
  }

  void _initializeAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOutCubic,
    ));

    _animationController.forward();
  }

  Future<void> _loadSavedRole() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedRole = prefs.getString('selected_role');
      if (savedRole != null && mounted) {
        setState(() {
          _selectedRole = savedRole;
        });
      }
    } catch (e) {
      // Handle error silently
    }
  }

  Future<void> _saveRole(String role) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('selected_role', role);
    } catch (e) {
      // Handle error silently
    }
  }

  void _selectRole(String roleId, String route) {
    // Haptic feedback
    HapticFeedback.lightImpact();

    setState(() {
      _selectedRole = roleId;
    });

    // Save role selection
    _saveRole(roleId);

    // Navigate after short delay for visual feedback
    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) {
        Navigator.pushNamed(context, route);
      }
    });
  }

  void _showRoleChangeDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Text(
            'Cambiar Rol',
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          content: Text(
            'Los diferentes roles tienen funcionalidades distintas. ¿Estás seguro de que quieres cambiar tu selección?',
            style: AppTheme.lightTheme.textTheme.bodyMedium,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text(
                'Cancelar',
                style: TextStyle(
                  color: AppTheme.lightTheme.colorScheme.onSurface
                      .withValues(alpha: 0.7),
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                setState(() {
                  _selectedRole = null;
                });
              },
              child: const Text('Confirmar'),
            ),
          ],
        );
      },
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: AnimatedBuilder(
          animation: _animationController,
          builder: (context, child) {
            return FadeTransition(
              opacity: _fadeAnimation,
              child: SlideTransition(
                position: _slideAnimation,
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      minHeight: MediaQuery.of(context).size.height -
                          MediaQuery.of(context).padding.top -
                          MediaQuery.of(context).padding.bottom,
                    ),
                    child: Column(
                      children: [
                        SizedBox(height: 4.h),

                        // Logo Header
                        const LogoHeaderWidget(),

                        SizedBox(height: 4.h),

                        // Title Section
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 4.w),
                          child: Column(
                            children: [
                              Text(
                                'Selecciona tu Rol',
                                style: AppTheme
                                    .lightTheme.textTheme.headlineSmall
                                    ?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color:
                                      AppTheme.lightTheme.colorScheme.onSurface,
                                ),
                                textAlign: TextAlign.center,
                              ),
                              SizedBox(height: 1.h),
                              Text(
                                'Elige cómo quieres usar RaidBus para acceder a las funciones específicas',
                                style: AppTheme.lightTheme.textTheme.bodyLarge
                                    ?.copyWith(
                                  color: AppTheme
                                      .lightTheme.colorScheme.onSurface
                                      .withValues(alpha: 0.7),
                                  height: 1.4,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),

                        SizedBox(height: 4.h),

                        // Role Cards
                        ..._roles.map((role) {
                          return RoleCardWidget(
                            title: role['title'],
                            description: role['description'],
                            iconName: role['iconName'],
                            isSelected: _selectedRole == role['id'],
                            onTap: () => _selectRole(role['id'], role['route']),
                          );
                        }).toList(),

                        SizedBox(height: 3.h),

                        // Change Later Info
                        const ChangeLaterWidget(),

                        SizedBox(height: 2.h),

                        // Role Change Button (if role already selected)
                        if (_selectedRole != null)
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 4.w),
                            child: TextButton.icon(
                              onPressed: _showRoleChangeDialog,
                              icon: CustomIconWidget(
                                iconName: 'swap_horiz',
                                color: AppTheme.lightTheme.colorScheme.primary,
                                size: 4.w,
                              ),
                              label: Text(
                                'Cambiar Selección',
                                style: AppTheme.lightTheme.textTheme.labelLarge
                                    ?.copyWith(
                                  color:
                                      AppTheme.lightTheme.colorScheme.primary,
                                ),
                              ),
                            ),
                          ),

                        SizedBox(height: 4.h),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
