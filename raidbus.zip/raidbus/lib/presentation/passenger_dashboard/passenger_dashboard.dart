import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/greeting_header_widget.dart';
import './widgets/popular_routes_widget.dart';
import './widgets/quick_schedule_widget.dart';
import './widgets/recent_searches_widget.dart';
import './widgets/search_bar_widget.dart';

class PassengerDashboard extends StatefulWidget {
  @override
  State<PassengerDashboard> createState() => _PassengerDashboardState();
}

class _PassengerDashboardState extends State<PassengerDashboard>
    with TickerProviderStateMixin {
  int _currentIndex = 0;
  bool _isRefreshing = false;
  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
      GlobalKey<RefreshIndicatorState>();

  // Mock data for schedules
  final List<Map<String, dynamic>> _scheduleData = [
    {
      "id": 1,
      "departureTime": "7:00 AM",
      "arrivalTime": "2:30 PM",
      "origin": "Managua",
      "destination": "Puerto Cabezas",
      "company": "Transporte Jairo Monzón",
      "duration": "7h 30min",
      "price": "450",
      "status": "available"
    },
    {
      "id": 2,
      "departureTime": "12:00 PM",
      "arrivalTime": "7:30 PM",
      "origin": "Managua",
      "destination": "Puerto Cabezas",
      "company": "Leonel Monzón",
      "duration": "7h 30min",
      "price": "420",
      "status": "available"
    },
    {
      "id": 3,
      "departureTime": "6:00 PM",
      "arrivalTime": "1:30 AM",
      "origin": "Managua",
      "destination": "Puerto Cabezas",
      "company": "Susana Monzón",
      "duration": "7h 30min",
      "price": "480",
      "status": "available"
    }
  ];

  // Mock data for popular routes
  final List<Map<String, dynamic>> _routesData = [
    {
      "id": 1,
      "name": "Managua ↔ Puerto Cabezas",
      "duration": "7h 30min",
      "price": "420",
      "companies": [
        "Transporte Jairo Monzón",
        "Leonel Monzón",
        "Susana Monzón",
        "Juan Quintana",
        "Aragón"
      ],
      "frequency": "5 salidas diarias",
      "description": "Ruta principal entre la capital y la costa caribeña"
    },
    {
      "id": 2,
      "name": "Puerto Cabezas ↔ Managua",
      "duration": "7h 30min",
      "price": "420",
      "companies": ["Montoya", "Amador", "Centeno", "Ingram", "Chow"],
      "frequency": "5 salidas diarias",
      "description": "Ruta de regreso desde la costa caribeña"
    }
  ];

  // Mock data for recent searches
  List<Map<String, dynamic>> _recentSearches = [
    {
      "id": 1,
      "origin": "Managua",
      "destination": "Puerto Cabezas",
      "date": "Hoy, 05 Sep",
      "searchTime": DateTime.now().subtract(Duration(hours: 2))
    },
    {
      "id": 2,
      "origin": "Puerto Cabezas",
      "destination": "Managua",
      "date": "Mañana, 06 Sep",
      "searchTime": DateTime.now().subtract(Duration(days: 1))
    }
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: _buildAppBar(),
      body: RefreshIndicator(
        key: _refreshIndicatorKey,
        onRefresh: _handleRefresh,
        color: AppTheme.lightTheme.primaryColor,
        child: SingleChildScrollView(
          physics: AlwaysScrollableScrollPhysics(),
          child: Column(
            children: [
              GreetingHeaderWidget(
                userName: "Carlos",
                currentTime: _getCurrentTime(),
                weatherInfo: "28°C Soleado",
              ),
              SizedBox(height: 2.h),
              SearchBarWidget(
                onSearch: _handleSearch,
                onVoiceSearch: _handleVoiceSearch,
              ),
              SizedBox(height: 1.h),
              QuickScheduleWidget(
                scheduleData: _scheduleData,
                onScheduleTap: _handleScheduleTap,
              ),
              SizedBox(height: 2.h),
              PopularRoutesWidget(
                routesData: _routesData,
                onRouteTap: _handleRouteTap,
              ),
              SizedBox(height: 2.h),
              RecentSearchesWidget(
                recentSearches: _recentSearches,
                onSearchTap: _handleRecentSearchTap,
                onClearAll: _handleClearRecentSearches,
              ),
              SizedBox(height: 10.h), // Bottom padding for FAB
            ],
          ),
        ),
      ),
      bottomNavigationBar: _buildBottomNavigationBar(),
      floatingActionButton: _buildFloatingActionButton(),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      drawer: _buildDrawer(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppTheme.secondaryLight,
      foregroundColor: Colors.white,
      elevation: 0,
      title: Text(
        'RaidBus',
        style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
          color: Colors.white,
          fontWeight: FontWeight.bold,
        ),
      ),
      centerTitle: true,
      leading: Builder(
        builder: (context) => IconButton(
          icon: CustomIconWidget(
            iconName: 'menu',
            color: Colors.white,
            size: 24,
          ),
          onPressed: () => Scaffold.of(context).openDrawer(),
        ),
      ),
      actions: [
        Stack(
          children: [
            IconButton(
              icon: CustomIconWidget(
                iconName: 'notifications',
                color: Colors.white,
                size: 24,
              ),
              onPressed: _handleNotificationTap,
            ),
            Positioned(
              right: 8,
              top: 8,
              child: Container(
                padding: EdgeInsets.all(2),
                decoration: BoxDecoration(
                  color: AppTheme.secondaryLight,
                  borderRadius: BorderRadius.circular(6),
                ),
                constraints: BoxConstraints(
                  minWidth: 12,
                  minHeight: 12,
                ),
                child: Text(
                  '2',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildBottomNavigationBar() {
    return BottomNavigationBar(
      currentIndex: _currentIndex,
      onTap: _handleBottomNavTap,
      type: BottomNavigationBarType.fixed,
      backgroundColor: Colors.white,
      selectedItemColor: AppTheme.lightTheme.primaryColor,
      unselectedItemColor: Colors.grey[600],
      selectedLabelStyle: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
        fontWeight: FontWeight.w500,
      ),
      unselectedLabelStyle: AppTheme.lightTheme.textTheme.bodySmall,
      items: [
        BottomNavigationBarItem(
          icon: CustomIconWidget(
            iconName: 'dashboard',
            color: _currentIndex == 0
                ? AppTheme.lightTheme.primaryColor
                : Colors.grey[600]!,
            size: 24,
          ),
          label: 'Dashboard',
        ),
        BottomNavigationBarItem(
          icon: CustomIconWidget(
            iconName: 'schedule',
            color: _currentIndex == 1
                ? AppTheme.lightTheme.primaryColor
                : Colors.grey[600]!,
            size: 24,
          ),
          label: 'Horarios',
        ),
        BottomNavigationBarItem(
          icon: CustomIconWidget(
            iconName: 'route',
            color: _currentIndex == 2
                ? AppTheme.lightTheme.primaryColor
                : Colors.grey[600]!,
            size: 24,
          ),
          label: 'Rutas',
        ),
        BottomNavigationBarItem(
          icon: CustomIconWidget(
            iconName: 'person',
            color: _currentIndex == 3
                ? AppTheme.lightTheme.primaryColor
                : Colors.grey[600]!,
            size: 24,
          ),
          label: 'Perfil',
        ),
      ],
    );
  }

  Widget _buildFloatingActionButton() {
    return FloatingActionButton.extended(
      onPressed: _handlePlanTrip,
      backgroundColor: AppTheme
          .secondaryLight, // Use AppTheme color instead of secondaryColor
      foregroundColor: Colors.white,
      icon: CustomIconWidget(
        iconName: 'add_location',
        color: Colors.white,
        size: 24,
      ),
      label: Text(
        'Planificar Viaje',
        style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
          color: Colors.white,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      child: Column(
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  AppTheme.lightTheme.primaryColor,
                  AppTheme.lightTheme.primaryColor.withValues(alpha: 0.8),
                ],
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: Colors.white.withValues(alpha: 0.2),
                  child: CustomIconWidget(
                    iconName: 'person',
                    color: Colors.white,
                    size: 32,
                  ),
                ),
                SizedBox(height: 2.h),
                Text(
                  'Carlos Mendoza',
                  style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  'Pasajero',
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    color: Colors.white.withValues(alpha: 0.8),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                ListTile(
                  leading: CustomIconWidget(
                    iconName: 'swap_horiz',
                    color: AppTheme.lightTheme.primaryColor,
                    size: 24,
                  ),
                  title: Text('Cambiar a Conductor'),
                  onTap: () => _handleRoleSwitch(),
                ),
                Divider(),
                ListTile(
                  leading: CustomIconWidget(
                    iconName: 'dashboard',
                    color: Colors.grey[600]!,
                    size: 24,
                  ),
                  title: Text('Dashboard'),
                  onTap: () => Navigator.pop(context),
                ),
                ListTile(
                  leading: CustomIconWidget(
                    iconName: 'schedule',
                    color: Colors.grey[600]!,
                    size: 24,
                  ),
                  title: Text('Horarios'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.pushNamed(context, '/schedule-viewer-screen');
                  },
                ),
                ListTile(
                  leading: CustomIconWidget(
                    iconName: 'route',
                    color: Colors.grey[600]!,
                    size: 24,
                  ),
                  title: Text('Rutas'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.pushNamed(context, '/route-information-screen');
                  },
                ),
                ListTile(
                  leading: CustomIconWidget(
                    iconName: 'person',
                    color: Colors.grey[600]!,
                    size: 24,
                  ),
                  title: Text('Mi Perfil'),
                  onTap: () => Navigator.pop(context),
                ),
                ListTile(
                  leading: CustomIconWidget(
                    iconName: 'settings',
                    color: Colors.grey[600]!,
                    size: 24,
                  ),
                  title: Text('Configuración'),
                  onTap: () => Navigator.pop(context),
                ),
                Divider(),
                ListTile(
                  leading: CustomIconWidget(
                    iconName: 'logout',
                    color: Colors.red[600]!,
                    size: 24,
                  ),
                  title: Text(
                    'Cerrar Sesión',
                    style: TextStyle(color: Colors.red[600]),
                  ),
                  onTap: () => _handleLogout(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _getCurrentTime() {
    final now = DateTime.now();
    final hour = now.hour.toString().padLeft(2, '0');
    final minute = now.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }

  Future<void> _handleRefresh() async {
    setState(() {
      _isRefreshing = true;
    });

    // Simulate API call
    await Future.delayed(Duration(seconds: 2));

    setState(() {
      _isRefreshing = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Datos actualizados'),
        backgroundColor: AppTheme.getStatusColor('success', isLight: true),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _handleSearch(String query) {
    if (query.trim().isEmpty) return;

    // Add to recent searches
    final newSearch = {
      "id": _recentSearches.length + 1,
      "origin": "Managua",
      "destination": "Puerto Cabezas",
      "date": "Hoy, ${DateTime.now().day} Sep",
      "searchTime": DateTime.now(),
      "query": query
    };

    setState(() {
      _recentSearches.insert(0, newSearch);
      if (_recentSearches.length > 5) {
        _recentSearches = _recentSearches.take(5).toList();
      }
    });

    Navigator.pushNamed(context, '/schedule-viewer-screen');
  }

  void _handleVoiceSearch() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Búsqueda por voz no disponible'),
        backgroundColor: AppTheme.getStatusColor('warning', isLight: true),
      ),
    );
  }

  void _handleScheduleTap(Map<String, dynamic> schedule) {
    Navigator.pushNamed(context, '/schedule-viewer-screen');
  }

  void _handleRouteTap(Map<String, dynamic> route) {
    Navigator.pushNamed(context, '/route-information-screen');
  }

  void _handleRecentSearchTap(Map<String, dynamic> search) {
    Navigator.pushNamed(context, '/schedule-viewer-screen');
  }

  void _handleClearRecentSearches() {
    setState(() {
      _recentSearches.clear();
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Búsquedas recientes eliminadas'),
        backgroundColor: AppTheme.getStatusColor('success', isLight: true),
      ),
    );
  }

  void _handleBottomNavTap(int index) {
    setState(() {
      _currentIndex = index;
    });

    switch (index) {
      case 0:
        // Already on dashboard
        break;
      case 1:
        Navigator.pushNamed(context, '/schedule-viewer-screen');
        break;
      case 2:
        Navigator.pushNamed(context, '/route-information-screen');
        break;
      case 3:
        // Navigate to profile (not implemented)
        break;
    }
  }

  void _handleNotificationTap() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('2 notificaciones nuevas'),
        backgroundColor: AppTheme.lightTheme.primaryColor,
      ),
    );
  }

  void _handlePlanTrip() {
    Navigator.pushNamed(context, '/route-information-screen');
  }

  void _handleRoleSwitch() {
    Navigator.pop(context);
    Navigator.pushNamed(context, '/role-selection-screen');
  }

  void _handleLogout() {
    Navigator.pop(context);
    Navigator.pushNamedAndRemoveUntil(
      context,
      '/login-screen',
      (route) => false,
    );
  }
}
