import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import './password_strength_widget.dart';
import './transport_company_dropdown_widget.dart';

class RegistrationFormWidget extends StatefulWidget {
  final String selectedRole;
  final Function(Map<String, dynamic>) onFormChanged;

  const RegistrationFormWidget({
    Key? key,
    required this.selectedRole,
    required this.onFormChanged,
  }) : super(key: key);

  @override
  State<RegistrationFormWidget> createState() => _RegistrationFormWidgetState();
}

class _RegistrationFormWidgetState extends State<RegistrationFormWidget> {
  final _formKey = GlobalKey<FormState>();
  final _fullNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  final _licenseController = TextEditingController();
  final _vehicleInfoController = TextEditingController();

  bool _isPasswordVisible = false;
  String? _selectedCompany;
  bool _acceptTerms = false;

  Map<String, String?> _errors = {};

  @override
  void initState() {
    super.initState();
    _fullNameController.addListener(_onFormChanged);
    _emailController.addListener(_onFormChanged);
    _phoneController.addListener(_onFormChanged);
    _passwordController.addListener(_onFormChanged);
    _licenseController.addListener(_onFormChanged);
    _vehicleInfoController.addListener(_onFormChanged);
  }

  @override
  void dispose() {
    _fullNameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    _licenseController.dispose();
    _vehicleInfoController.dispose();
    super.dispose();
  }

  void _onFormChanged() {
    final formData = {
      'fullName': _fullNameController.text,
      'email': _emailController.text,
      'phone': _phoneController.text,
      'password': _passwordController.text,
      'licenseNumber': _licenseController.text,
      'vehicleInfo': _vehicleInfoController.text,
      'transportCompany': _selectedCompany,
      'acceptTerms': _acceptTerms,
      'isValid': _isFormValid(),
    };
    widget.onFormChanged(formData);
  }

  bool _isFormValid() {
    return _fullNameController.text.isNotEmpty &&
        _emailController.text.isNotEmpty &&
        _phoneController.text.isNotEmpty &&
        _passwordController.text.length >= 8 &&
        (widget.selectedRole == 'passenger' ||
            (_licenseController.text.isNotEmpty &&
                _vehicleInfoController.text.isNotEmpty &&
                _selectedCompany != null)) &&
        _acceptTerms;
  }

  String? _validateFullName(String? value) {
    if (value == null || value.isEmpty) {
      return 'El nombre completo es requerido';
    }
    if (value.length < 2) {
      return 'El nombre debe tener al menos 2 caracteres';
    }
    return null;
  }

  String? _validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'El correo electrónico es requerido';
    }
    final emailRegex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    if (!emailRegex.hasMatch(value)) {
      return 'Ingrese un correo electrónico válido';
    }
    return null;
  }

  String? _validatePhone(String? value) {
    if (value == null || value.isEmpty) {
      return 'El número de teléfono es requerido';
    }
    final phoneRegex = RegExp(r'^\d{8}$');
    if (!phoneRegex.hasMatch(value)) {
      return 'Ingrese un número válido (8 dígitos)';
    }
    return null;
  }

  String? _validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'La contraseña es requerida';
    }
    if (value.length < 8) {
      return 'La contraseña debe tener al menos 8 caracteres';
    }
    return null;
  }

  String? _validateLicense(String? value) {
    if (widget.selectedRole == 'driver' && (value == null || value.isEmpty)) {
      return 'El número de licencia es requerido';
    }
    return null;
  }

  String? _validateVehicleInfo(String? value) {
    if (widget.selectedRole == 'driver' && (value == null || value.isEmpty)) {
      return 'La información del vehículo es requerida';
    }
    return null;
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required String? Function(String?) validator,
    TextInputType keyboardType = TextInputType.text,
    bool obscureText = false,
    Widget? suffixIcon,
    List<TextInputFormatter>? inputFormatters,
    int maxLines = 1,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: AppTheme.lightTheme.textTheme.labelLarge?.copyWith(
            color: AppTheme.lightTheme.colorScheme.onSurface,
            fontWeight: FontWeight.w500,
          ),
        ),
        SizedBox(height: 1.h),
        TextFormField(
          controller: controller,
          validator: validator,
          keyboardType: keyboardType,
          obscureText: obscureText,
          inputFormatters: inputFormatters,
          maxLines: maxLines,
          style: AppTheme.lightTheme.textTheme.bodyMedium,
          decoration: InputDecoration(
            hintText: hint,
            suffixIcon: suffixIcon,
            contentPadding:
                EdgeInsets.symmetric(horizontal: 4.w, vertical: 3.h),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Full Name Field
          _buildTextField(
            controller: _fullNameController,
            label: 'Nombre Completo *',
            hint: 'Ingrese su nombre completo',
            validator: _validateFullName,
            keyboardType: TextInputType.name,
          ),

          SizedBox(height: 3.h),

          // Email Field
          _buildTextField(
            controller: _emailController,
            label: 'Correo Electrónico *',
            hint: 'ejemplo@correo.com',
            validator: _validateEmail,
            keyboardType: TextInputType.emailAddress,
          ),

          SizedBox(height: 3.h),

          // Phone Field
          _buildTextField(
            controller: _phoneController,
            label: 'Número de Teléfono *',
            hint: 'Ej: 87654321',
            validator: _validatePhone,
            keyboardType: TextInputType.phone,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
              LengthLimitingTextInputFormatter(8),
            ],
          ),

          SizedBox(height: 1.h),

          // Phone Format Helper
          Row(
            children: [
              CustomIconWidget(
                iconName: 'info_outline',
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 16,
              ),
              SizedBox(width: 2.w),
              Text(
                'Formato: +505 XXXX-XXXX (sin espacios ni guiones)',
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),

          SizedBox(height: 3.h),

          // Password Field
          _buildTextField(
            controller: _passwordController,
            label: 'Contraseña *',
            hint: 'Ingrese una contraseña segura',
            validator: _validatePassword,
            obscureText: !_isPasswordVisible,
            suffixIcon: IconButton(
              onPressed: () {
                setState(() {
                  _isPasswordVisible = !_isPasswordVisible;
                });
              },
              icon: CustomIconWidget(
                iconName: _isPasswordVisible ? 'visibility_off' : 'visibility',
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 20,
              ),
            ),
          ),

          // Password Strength Indicator
          PasswordStrengthWidget(password: _passwordController.text),

          // Driver-specific fields
          if (widget.selectedRole == 'driver') ...[
            SizedBox(height: 3.h),

            // License Number Field
            _buildTextField(
              controller: _licenseController,
              label: 'Número de Licencia *',
              hint: 'Ingrese su número de licencia',
              validator: _validateLicense,
            ),

            SizedBox(height: 3.h),

            // Transport Company Dropdown
            TransportCompanyDropdownWidget(
              selectedCompany: _selectedCompany,
              onChanged: (value) {
                setState(() {
                  _selectedCompany = value;
                });
                _onFormChanged();
              },
              errorText:
                  widget.selectedRole == 'driver' && _selectedCompany == null
                      ? 'Seleccione una empresa de transporte'
                      : null,
            ),

            SizedBox(height: 3.h),

            // Vehicle Information Field
            _buildTextField(
              controller: _vehicleInfoController,
              label: 'Información del Vehículo *',
              hint: 'Ej: Placa, modelo, año',
              validator: _validateVehicleInfo,
              maxLines: 2,
            ),
          ],

          SizedBox(height: 4.h),

          // Terms and Conditions Checkbox
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Checkbox(
                value: _acceptTerms,
                onChanged: (value) {
                  setState(() {
                    _acceptTerms = value ?? false;
                  });
                  _onFormChanged();
                },
              ),
              Expanded(
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      _acceptTerms = !_acceptTerms;
                    });
                    _onFormChanged();
                  },
                  child: Padding(
                    padding: EdgeInsets.only(top: 2.w),
                    child: RichText(
                      text: TextSpan(
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color: AppTheme.lightTheme.colorScheme.onSurface,
                        ),
                        children: [
                          const TextSpan(text: 'Acepto los '),
                          TextSpan(
                            text: 'Términos y Condiciones',
                            style: TextStyle(
                              color: AppTheme.lightTheme.colorScheme.primary,
                              fontWeight: FontWeight.w500,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                          const TextSpan(text: ' y la '),
                          TextSpan(
                            text: 'Política de Privacidad',
                            style: TextStyle(
                              color: AppTheme.lightTheme.colorScheme.primary,
                              fontWeight: FontWeight.w500,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
