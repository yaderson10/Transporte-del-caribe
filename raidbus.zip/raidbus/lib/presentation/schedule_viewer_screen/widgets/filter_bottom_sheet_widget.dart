import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class FilterBottomSheetWidget extends StatefulWidget {
  final Map<String, dynamic> currentFilters;
  final Function(Map<String, dynamic>) onFiltersApplied;

  const FilterBottomSheetWidget({
    Key? key,
    required this.currentFilters,
    required this.onFiltersApplied,
  }) : super(key: key);

  @override
  State<FilterBottomSheetWidget> createState() =>
      _FilterBottomSheetWidgetState();
}

class _FilterBottomSheetWidgetState extends State<FilterBottomSheetWidget> {
  late Map<String, dynamic> _filters;

  final List<String> _companies = [
    'Transporte Jairo Monzón',
    'Leonel Monzón',
    'Susana Monzón',
    'Juan Quintana',
    'Aragón',
    'Montoya',
    'Amador',
    'Centeno',
    'Ingram',
    'Chow',
    'Acevedo',
    'Dunkan',
    'Fermín Romero',
    'Lazo',
  ];

  final List<Map<String, String>> _timeRanges = [
    {'label': 'Madrugada (6:00 - 8:00)', 'value': 'early_morning'},
    {'label': 'Mañana (8:00 - 12:00)', 'value': 'morning'},
    {'label': 'Tarde (12:00 - 18:00)', 'value': 'afternoon'},
    {'label': 'Noche (18:00 - 23:00)', 'value': 'evening'},
  ];

  @override
  void initState() {
    super.initState();
    _filters = Map<String, dynamic>.from(widget.currentFilters);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 80.h,
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          _buildHeader(),
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildTimeRangeSection(),
                  SizedBox(height: 3.h),
                  _buildCompanySection(),
                  SizedBox(height: 3.h),
                  _buildServiceTypeSection(),
                  SizedBox(height: 4.h),
                ],
              ),
            ),
          ),
          _buildActionButtons(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color:
                AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
          ),
        ),
      ),
      child: Row(
        children: [
          Text(
            'Filtros',
            style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          const Spacer(),
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: CustomIconWidget(
              iconName: 'close',
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 24,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTimeRangeSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Horario de Salida',
          style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 1.h),
        ..._timeRanges.map((timeRange) => _buildTimeRangeOption(timeRange)),
      ],
    );
  }

  Widget _buildTimeRangeOption(Map<String, String> timeRange) {
    final bool isSelected = (_filters['timeRanges'] as List<String>? ?? [])
        .contains(timeRange['value']!);

    return CheckboxListTile(
      title: Text(
        timeRange['label']!,
        style: AppTheme.lightTheme.textTheme.bodyMedium,
      ),
      value: isSelected,
      onChanged: (bool? value) {
        setState(() {
          final List<String> timeRanges =
              List<String>.from(_filters['timeRanges'] ?? []);

          if (value == true) {
            timeRanges.add(timeRange['value']!);
          } else {
            timeRanges.remove(timeRange['value']!);
          }

          _filters['timeRanges'] = timeRanges;
        });
      },
      contentPadding: EdgeInsets.zero,
      controlAffinity: ListTileControlAffinity.leading,
    );
  }

  Widget _buildCompanySection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Empresa de Transporte',
          style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 1.h),
        Container(
          constraints: BoxConstraints(maxHeight: 30.h),
          child: SingleChildScrollView(
            child: Column(
              children: _companies
                  .map((company) => _buildCompanyOption(company))
                  .toList(),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCompanyOption(String company) {
    final bool isSelected =
        (_filters['companies'] as List<String>? ?? []).contains(company);

    return CheckboxListTile(
      title: Text(
        company,
        style: AppTheme.lightTheme.textTheme.bodyMedium,
      ),
      value: isSelected,
      onChanged: (bool? value) {
        setState(() {
          final List<String> companies =
              List<String>.from(_filters['companies'] ?? []);

          if (value == true) {
            companies.add(company);
          } else {
            companies.remove(company);
          }

          _filters['companies'] = companies;
        });
      },
      contentPadding: EdgeInsets.zero,
      controlAffinity: ListTileControlAffinity.leading,
    );
  }

  Widget _buildServiceTypeSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Tipo de Servicio',
          style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 1.h),
        _buildServiceTypeOption('Directo', 'direct'),
        _buildServiceTypeOption('Con Paradas', 'with_stops'),
      ],
    );
  }

  Widget _buildServiceTypeOption(String label, String value) {
    final bool isSelected =
        (_filters['serviceTypes'] as List<String>? ?? []).contains(value);

    return CheckboxListTile(
      title: Text(
        label,
        style: AppTheme.lightTheme.textTheme.bodyMedium,
      ),
      value: isSelected,
      onChanged: (bool? checked) {
        setState(() {
          final List<String> serviceTypes =
              List<String>.from(_filters['serviceTypes'] ?? []);

          if (checked == true) {
            serviceTypes.add(value);
          } else {
            serviceTypes.remove(value);
          }

          _filters['serviceTypes'] = serviceTypes;
        });
      },
      contentPadding: EdgeInsets.zero,
      controlAffinity: ListTileControlAffinity.leading,
    );
  }

  Widget _buildActionButtons() {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(
            color:
                AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton(
              onPressed: () {
                setState(() {
                  _filters = {
                    'timeRanges': <String>[],
                    'companies': <String>[],
                    'serviceTypes': <String>[],
                  };
                });
              },
              child: const Text('Limpiar'),
            ),
          ),
          SizedBox(width: 4.w),
          Expanded(
            flex: 2,
            child: ElevatedButton(
              onPressed: () {
                widget.onFiltersApplied(_filters);
                Navigator.pop(context);
              },
              child: const Text('Aplicar Filtros'),
            ),
          ),
        ],
      ),
    );
  }
}