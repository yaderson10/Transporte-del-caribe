import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/calendar_widget.dart';
import './widgets/filter_bottom_sheet_widget.dart';
import './widgets/route_selector_widget.dart';
import './widgets/schedule_card_widget.dart';
import './widgets/schedule_detail_modal_widget.dart';

class ScheduleViewerScreen extends StatefulWidget {
  const ScheduleViewerScreen({Key? key}) : super(key: key);

  @override
  State<ScheduleViewerScreen> createState() => _ScheduleViewerScreenState();
}

class _ScheduleViewerScreenState extends State<ScheduleViewerScreen> {
  String _selectedRoute = 'managua_to_puerto';
  DateTime _selectedDate = DateTime.now();
  Map<String, dynamic> _activeFilters = {
    'timeRanges': <String>[],
    'companies': <String>[],
    'serviceTypes': <String>[],
  };
  bool _isLoading = false;
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();

  // Mock schedule data
  final List<Map<String, dynamic>> _managauToPuertoSchedules = [
    {
      "id": 1,
      "departureTime": "7:00 AM",
      "arrivalTime": "2:30 PM",
      "company": "Transporte Jairo Monzón",
      "duration": "7h 30min",
      "status": "on_time",
      "availableSeats": 15,
      "totalSeats": 45,
      "origin": "Managua",
      "destination": "Puerto Cabezas",
      "distance": "465 km",
      "estimatedPrice": "C\$ 450",
      "serviceType": "Directo",
      "features": ["Aire Acondicionado", "WiFi", "Baño", "TV"],
      "phone": "+505 2222-3333",
      "terminal": "Terminal de Buses Mayoreo",
      "timeRange": "morning",
    },
    {
      "id": 2,
      "departureTime": "12:00 PM",
      "arrivalTime": "7:30 PM",
      "company": "Leonel Monzón",
      "duration": "7h 30min",
      "status": "on_time",
      "availableSeats": 8,
      "totalSeats": 45,
      "origin": "Managua",
      "destination": "Puerto Cabezas",
      "distance": "465 km",
      "estimatedPrice": "C\$ 450",
      "serviceType": "Con Paradas",
      "features": ["Aire Acondicionado", "Baño"],
      "phone": "+505 2222-4444",
      "terminal": "Terminal de Buses Mayoreo",
      "timeRange": "afternoon",
    },
    {
      "id": 3,
      "departureTime": "6:00 PM",
      "arrivalTime": "1:30 AM",
      "company": "Susana Monzón",
      "duration": "7h 30min",
      "status": "delayed",
      "availableSeats": 22,
      "totalSeats": 45,
      "origin": "Managua",
      "destination": "Puerto Cabezas",
      "distance": "465 km",
      "estimatedPrice": "C\$ 450",
      "serviceType": "Directo",
      "features": [
        "Aire Acondicionado",
        "WiFi",
        "Baño",
        "TV",
        "Cargadores USB"
      ],
      "phone": "+505 2222-5555",
      "terminal": "Terminal de Buses Mayoreo",
      "timeRange": "evening",
    },
    {
      "id": 4,
      "departureTime": "8:30 PM",
      "arrivalTime": "4:00 AM",
      "company": "Juan Quintana",
      "duration": "7h 30min",
      "status": "on_time",
      "availableSeats": 12,
      "totalSeats": 45,
      "origin": "Managua",
      "destination": "Puerto Cabezas",
      "distance": "465 km",
      "estimatedPrice": "C\$ 450",
      "serviceType": "Directo",
      "features": ["Aire Acondicionado", "Baño", "TV"],
      "phone": "+505 2222-6666",
      "terminal": "Terminal de Buses Mayoreo",
      "timeRange": "evening",
    },
    {
      "id": 5,
      "departureTime": "10:00 PM",
      "arrivalTime": "5:30 AM",
      "company": "Aragón",
      "duration": "7h 30min",
      "status": "on_time",
      "availableSeats": 18,
      "totalSeats": 45,
      "origin": "Managua",
      "destination": "Puerto Cabezas",
      "distance": "465 km",
      "estimatedPrice": "C\$ 450",
      "serviceType": "Con Paradas",
      "features": ["Aire Acondicionado", "Baño"],
      "phone": "+505 2222-7777",
      "terminal": "Terminal de Buses Mayoreo",
      "timeRange": "evening",
    },
  ];

  final List<Map<String, dynamic>> _puertoToManaguaSchedules = [
    {
      "id": 6,
      "departureTime": "6:00 AM",
      "arrivalTime": "1:30 PM",
      "company": "Montoya",
      "duration": "7h 30min",
      "status": "on_time",
      "availableSeats": 20,
      "totalSeats": 45,
      "origin": "Puerto Cabezas",
      "destination": "Managua",
      "distance": "465 km",
      "estimatedPrice": "C\$ 450",
      "serviceType": "Directo",
      "features": ["Aire Acondicionado", "WiFi", "Baño", "TV"],
      "phone": "+505 2555-1111",
      "terminal": "Terminal Puerto Cabezas",
      "timeRange": "early_morning",
    },
    {
      "id": 7,
      "departureTime": "10:00 AM",
      "arrivalTime": "5:30 PM",
      "company": "Amador",
      "duration": "7h 30min",
      "status": "on_time",
      "availableSeats": 14,
      "totalSeats": 45,
      "origin": "Puerto Cabezas",
      "destination": "Managua",
      "distance": "465 km",
      "estimatedPrice": "C\$ 450",
      "serviceType": "Con Paradas",
      "features": ["Aire Acondicionado", "Baño"],
      "phone": "+505 2555-2222",
      "terminal": "Terminal Puerto Cabezas",
      "timeRange": "morning",
    },
    {
      "id": 8,
      "departureTime": "1:00 PM",
      "arrivalTime": "8:30 PM",
      "company": "Centeno",
      "duration": "7h 30min",
      "status": "on_time",
      "availableSeats": 9,
      "totalSeats": 45,
      "origin": "Puerto Cabezas",
      "destination": "Managua",
      "distance": "465 km",
      "estimatedPrice": "C\$ 450",
      "serviceType": "Directo",
      "features": [
        "Aire Acondicionado",
        "WiFi",
        "Baño",
        "TV",
        "Cargadores USB"
      ],
      "phone": "+505 2555-3333",
      "terminal": "Terminal Puerto Cabezas",
      "timeRange": "afternoon",
    },
    {
      "id": 9,
      "departureTime": "4:00 PM",
      "arrivalTime": "11:30 PM",
      "company": "Ingram",
      "duration": "7h 30min",
      "status": "delayed",
      "availableSeats": 25,
      "totalSeats": 45,
      "origin": "Puerto Cabezas",
      "destination": "Managua",
      "distance": "465 km",
      "estimatedPrice": "C\$ 450",
      "serviceType": "Con Paradas",
      "features": ["Aire Acondicionado", "Baño"],
      "phone": "+505 2555-4444",
      "terminal": "Terminal Puerto Cabezas",
      "timeRange": "afternoon",
    },
    {
      "id": 10,
      "departureTime": "7:00 PM",
      "arrivalTime": "2:30 AM",
      "company": "Chow",
      "duration": "7h 30min",
      "status": "on_time",
      "availableSeats": 11,
      "totalSeats": 45,
      "origin": "Puerto Cabezas",
      "destination": "Managua",
      "distance": "465 km",
      "estimatedPrice": "C\$ 450",
      "serviceType": "Directo",
      "features": ["Aire Acondicionado", "WiFi", "Baño", "TV"],
      "phone": "+505 2555-5555",
      "terminal": "Terminal Puerto Cabezas",
      "timeRange": "evening",
    },
  ];

  // Mock availability data for calendar
  final Map<DateTime, int> _availabilityData = {};

  @override
  void initState() {
    super.initState();
    _generateAvailabilityData();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _generateAvailabilityData() {
    final now = DateTime.now();
    for (int i = 0; i < 30; i++) {
      final date = DateTime(now.year, now.month, now.day + i);
      _availabilityData[date] = (5 + (i % 10)); // Mock availability 5-14
    }
  }

  List<Map<String, dynamic>> get _currentSchedules {
    return _selectedRoute == 'managua_to_puerto'
        ? _managauToPuertoSchedules
        : _puertoToManaguaSchedules;
  }

  List<Map<String, dynamic>> get _filteredSchedules {
    List<Map<String, dynamic>> schedules = _currentSchedules;

    // Apply search filter
    if (_searchQuery.isNotEmpty) {
      schedules = schedules.where((schedule) {
        final company = (schedule['company'] as String).toLowerCase();
        final departureTime =
            (schedule['departureTime'] as String).toLowerCase();
        final query = _searchQuery.toLowerCase();
        return company.contains(query) || departureTime.contains(query);
      }).toList();
    }

    // Apply time range filter
    final timeRanges = _activeFilters['timeRanges'] as List<String>;
    if (timeRanges.isNotEmpty) {
      schedules = schedules.where((schedule) {
        return timeRanges.contains(schedule['timeRange']);
      }).toList();
    }

    // Apply company filter
    final companies = _activeFilters['companies'] as List<String>;
    if (companies.isNotEmpty) {
      schedules = schedules.where((schedule) {
        return companies.contains(schedule['company']);
      }).toList();
    }

    // Apply service type filter
    final serviceTypes = _activeFilters['serviceTypes'] as List<String>;
    if (serviceTypes.isNotEmpty) {
      schedules = schedules.where((schedule) {
        final serviceType = schedule['serviceType'] as String;
        return serviceTypes.any((type) {
          if (type == 'direct') return serviceType == 'Directo';
          if (type == 'with_stops') return serviceType == 'Con Paradas';
          return false;
        });
      }).toList();
    }

    return schedules;
  }

  Future<void> _refreshSchedules() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate API call
    await Future.delayed(const Duration(seconds: 1));

    setState(() {
      _isLoading = false;
    });
  }

  void _showFilterBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => FilterBottomSheetWidget(
        currentFilters: _activeFilters,
        onFiltersApplied: (filters) {
          setState(() {
            _activeFilters = filters;
          });
        },
      ),
    );
  }

  void _showScheduleDetail(Map<String, dynamic> scheduleData) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => ScheduleDetailModalWidget(
        scheduleData: scheduleData,
      ),
    );
  }

  void _shareSchedule() {
    final route = _selectedRoute == 'managua_to_puerto'
        ? 'Managua → Puerto Cabezas'
        : 'Puerto Cabezas → Managua';
    final date =
        '${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}';

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Compartiendo horarios de $route para $date'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  bool get _hasActiveFilters {
    final timeRanges = _activeFilters['timeRanges'] as List<String>;
    final companies = _activeFilters['companies'] as List<String>;
    final serviceTypes = _activeFilters['serviceTypes'] as List<String>;

    return timeRanges.isNotEmpty ||
        companies.isNotEmpty ||
        serviceTypes.isNotEmpty;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: _buildAppBar(),
      body: RefreshIndicator(
        onRefresh: _refreshSchedules,
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Column(
                children: [
                  SizedBox(height: 2.h),
                  RouteSelector(),
                  SizedBox(height: 2.h),
                  CalendarSection(),
                  SizedBox(height: 2.h),
                  SearchAndFilterSection(),
                  SizedBox(height: 1.h),
                ],
              ),
            ),
            _isLoading
                ? SliverToBoxAdapter(
                    child: Container(
                      height: 30.h,
                      child: const Center(
                        child: CircularProgressIndicator(),
                      ),
                    ),
                  )
                : _filteredSchedules.isEmpty
                    ? SliverToBoxAdapter(
                        child: _buildEmptyState(),
                      )
                    : SliverList(
                        delegate: SliverChildBuilderDelegate(
                          (context, index) {
                            final schedule = _filteredSchedules[index];
                            return ScheduleCardWidget(
                              scheduleData: schedule,
                              onTap: () => _showScheduleDetail(schedule),
                            );
                          },
                          childCount: _filteredSchedules.length,
                        ),
                      ),
            SliverToBoxAdapter(
              child: SizedBox(height: 4.h),
            ),
          ],
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: const Text('Horarios de Buses'),
      leading: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: CustomIconWidget(
          iconName: 'arrow_back',
          color: AppTheme.lightTheme.colorScheme.onPrimary,
          size: 24,
        ),
      ),
      actions: [
        GestureDetector(
          onTap: _shareSchedule,
          child: Padding(
            padding: EdgeInsets.only(right: 4.w),
            child: CustomIconWidget(
              iconName: 'share',
              color: AppTheme.lightTheme.colorScheme.onPrimary,
              size: 24,
            ),
          ),
        ),
      ],
    );
  }

  Widget RouteSelector() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: RouteSelectorWidget(
        selectedRoute: _selectedRoute,
        onRouteChanged: (route) {
          setState(() {
            _selectedRoute = route;
          });
        },
      ),
    );
  }

  Widget CalendarSection() {
    return CalendarWidget(
      selectedDate: _selectedDate,
      onDateSelected: (date) {
        setState(() {
          _selectedDate = date;
        });
      },
      availabilityData: _availabilityData,
    );
  }

  Widget SearchAndFilterSection() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Row(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppTheme.lightTheme.colorScheme.outline
                      .withValues(alpha: 0.2),
                ),
              ),
              child: TextField(
                controller: _searchController,
                onChanged: (value) {
                  setState(() {
                    _searchQuery = value;
                  });
                },
                decoration: InputDecoration(
                  hintText: 'Buscar por empresa o horario...',
                  prefixIcon: Padding(
                    padding: EdgeInsets.all(3.w),
                    child: CustomIconWidget(
                      iconName: 'search',
                      color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      size: 20,
                    ),
                  ),
                  suffixIcon: _searchQuery.isNotEmpty
                      ? GestureDetector(
                          onTap: () {
                            _searchController.clear();
                            setState(() {
                              _searchQuery = '';
                            });
                          },
                          child: Padding(
                            padding: EdgeInsets.all(3.w),
                            child: CustomIconWidget(
                              iconName: 'clear',
                              color: AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                              size: 20,
                            ),
                          ),
                        )
                      : null,
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(
                    horizontal: 4.w,
                    vertical: 1.5.h,
                  ),
                ),
              ),
            ),
          ),
          SizedBox(width: 3.w),
          GestureDetector(
            onTap: _showFilterBottomSheet,
            child: Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: _hasActiveFilters
                    ? AppTheme.lightTheme.colorScheme.primary
                    : AppTheme.lightTheme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _hasActiveFilters
                      ? AppTheme.lightTheme.colorScheme.primary
                      : AppTheme.lightTheme.colorScheme.outline
                          .withValues(alpha: 0.2),
                ),
              ),
              child: CustomIconWidget(
                iconName: 'tune',
                color: _hasActiveFilters
                    ? AppTheme.lightTheme.colorScheme.onPrimary
                    : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 24,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Container(
      height: 40.h,
      padding: EdgeInsets.symmetric(horizontal: 8.w),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: 'search_off',
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 64,
          ),
          SizedBox(height: 2.h),
          Text(
            'No se encontraron horarios',
            style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 1.h),
          Text(
            'Intenta cambiar los filtros o seleccionar otra fecha',
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 3.h),
          OutlinedButton(
            onPressed: () {
              setState(() {
                _activeFilters = {
                  'timeRanges': <String>[],
                  'companies': <String>[],
                  'serviceTypes': <String>[],
                };
                _searchController.clear();
                _searchQuery = '';
              });
            },
            child: const Text('Limpiar Filtros'),
          ),
        ],
      ),
    );
  }
}
