import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class RoleIndicatorWidget extends StatelessWidget {
  final String userRole;

  const RoleIndicatorWidget({
    Key? key,
    required this.userRole,
  }) : super(key: key);

  Color _getRoleColor() {
    return userRole.toLowerCase() == 'passenger'
        ? AppTheme.lightTheme.colorScheme.tertiary
        : AppTheme.lightTheme.colorScheme.tertiaryContainer;
  }

  String _getRoleIcon() {
    return userRole.toLowerCase() == 'passenger' ? 'person' : 'drive_eta';
  }

  String _getRoleText() {
    return userRole.toLowerCase() == 'passenger' ? 'Pasajero' : 'Conductor';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
      decoration: BoxDecoration(
        color: _getRoleColor().withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: _getRoleColor().withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomIconWidget(
            iconName: _getRoleIcon(),
            color: _getRoleColor(),
            size: 5.w,
          ),
          SizedBox(width: 2.w),
          Text(
            _getRoleText(),
            style: AppTheme.lightTheme.textTheme.labelLarge?.copyWith(
              color: _getRoleColor(),
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}
